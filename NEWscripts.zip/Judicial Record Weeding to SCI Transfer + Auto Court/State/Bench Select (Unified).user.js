// ==UserScript==
// @name         Judicial Record Weeding to SCI Transfer + Auto Court/State/Bench Select (Unified)
// @namespace    http://tampermonkey.net/
// @version      2.2
// @description  Bridges internal weeding-details page with SCI case-status site: auto-fills court/state/bench dropdowns, transfers case no/date, syncs captcha, and cleanly resets output on every new search
// @match        http://10.145.22.11:8888/add_weeding_details.php*
// @match        https://www.sci.gov.in/case-status-court/*
// @match        https://www.sci.gov.in/case-status-court
// @grant        GM_setValue
// @grant        GM_getValue
// @run-at       document-end
// ==/UserScript==

(function () {
    'use strict';

    // ============================================================
    // SHARED HELPERS
    // ============================================================
    function convertDateFormat(dateStr) {
        if (!dateStr) return "";
        const months = {
            "JAN": "01", "FEB": "02", "MAR": "03", "APR": "04", "MAY": "05", "JUN": "06",
            "JUL": "07", "AUG": "08", "SEP": "09", "OCT": "10", "NOV": "11", "DEC": "12"
        };
        let parts = dateStr.toUpperCase().split('-');
        if (parts.length === 3) {
            let day = parts[0].padStart(2, '0');
            let monthNum = months[parts[1]] || parts[1];
            let year = parts[2];
            return `${day}-${monthNum}-${year}`;
        }
        return dateStr;
    }

    function getBase64Image(img) {
        try {
            let canvas = document.createElement("canvas");
            canvas.width = img.naturalWidth || img.width;
            canvas.height = img.naturalHeight || img.height;
            let ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0);
            return canvas.toDataURL("image/png");
        } catch (e) {
            console.log('SCI Bridge: Failed to convert captcha image to Base64', e);
            return null;
        }
    }

    // ============================================================
    // SITE 1: INTERNAL WEEDING DETAILS PAGE (10.145.22.11)
    // ============================================================
    if (window.location.href.includes("10.145.22.11")) {

        // --- Build floating captcha + live-output panel ---
        let captchaContainer = document.createElement("div");
        captchaContainer.id = "sci-captcha-container";
        captchaContainer.style = "position: fixed; top: 10px; right: 10px; z-index: 9999; padding: 10px; background: #fff; border: 2px solid #ffc107; border-radius: 5px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 220px; text-align: center; max-height: 90vh; overflow-y: auto;";
        captchaContainer.innerHTML = `
            <div style="font-weight:bold; font-size:12px; margin-bottom:5px; color:#333;">SCI Captcha</div>
            <img id="sci-captcha-img" src="" alt="Waiting for SCI site..." style="max-width: 100%; border: 1px solid #ccc; height: 40px; background: #eee; display: block; margin: 0 auto 5px auto;"/>
            <input type="text" id="sci-captcha-input" placeholder="Enter Captcha" style="width: 100%; padding: 4px; box-sizing: border-box; text-align: center; margin-bottom: 5px; border: 1px solid #ccc; border-radius:3px;"/>
            <button type="button" id="sci-captcha-submit" class="btn btn-primary" style="width: 100%; font-weight: bold; padding: 5px; font-size:12px; margin-bottom: 10px;">Submit to SCI</button>

            <hr style="border: 0; border-top: 1px solid #ccc; margin: 10px 0;">

            <div style="font-weight:bold; font-size:11px; margin-bottom:5px; color:#555; text-align: left;">Supreme Court Output:</div>
            <div id="sci-live-output" style="font-size: 11px; text-align: left; padding: 5px; background: #fafafa; border: 1px dashed #aaa; min-height: 40px; max-height: 300px; overflow-y: auto; color: #333;">
                Waiting for search...
            </div>
        `;
        document.body.appendChild(captchaContainer);

        function resetOutputPanel(message) {
            const img = document.querySelector("#sci-captcha-img");
            const out = document.querySelector("#sci-live-output");
            const input = document.querySelector("#sci-captcha-input");
            if (img) { img.src = ""; img.alt = "Awaiting new captcha..."; }
            if (out) out.innerHTML = message || "Waiting for search...";
            if (input) input.value = "";
        }

        // Reflect stored captcha image / live output onto the panel
        setInterval(() => {
            let base64Img = GM_getValue("sci_captcha_base64");
            let imgElement = document.querySelector("#sci-captcha-img");
            if (imgElement) {
                imgElement.src = base64Img ? base64Img : "";
                if (!base64Img) imgElement.alt = "Awaiting new captcha...";
            }

            let liveOutput = GM_getValue("sci_search_results_html");
            let outputDiv = document.querySelector("#sci-live-output");
            if (outputDiv) {
                outputDiv.innerHTML = liveOutput ? liveOutput : "Waiting for search...";
            }
        }, 500);

        // Submit captcha solution typed by the user
        document.querySelector("#sci-captcha-submit").addEventListener("click", function () {
            let val = document.querySelector("#sci-captcha-input").value.trim();
            if (val) {
                GM_setValue("sci_search_results_html", "Processing search request...");
                GM_setValue("sci_captcha_solution", val);
                GM_setValue("sci_trigger_submit", true);
                document.querySelector("#sci-captcha-input").value = "";
            } else {
                alert("Please enter the captcha value first.");
            }
        });

        // Watch for the native Submit button (get_details(0)) and the local #output block
        const observer = new MutationObserver(() => {
            let nativeSubmitBtn = document.querySelector("button[name='btn_diary']");
            if (nativeSubmitBtn && !nativeSubmitBtn.classList.contains("patched-chain")) {
                nativeSubmitBtn.classList.add("patched-chain");

                nativeSubmitBtn.addEventListener("click", function () {
                    console.log('SCI Bridge: Submit (get_details) clicked - resetting SCI panel for new case.');

                    // ---- HARD RESET: wipe every stored key so no stale data can reappear ----
                    GM_setValue("sci_search_results_html", "");
                    GM_setValue("sci_captcha_base64", "");
                    GM_setValue("sci_case_no", "");
                    GM_setValue("sci_date", "");
                    GM_setValue("sci_captcha_solution", "");
                    GM_setValue("sci_trigger_submit", false);
                    GM_setValue("sci_reset_token", Date.now()); // tells SCI tab a fresh cycle has begun

                    // Reflect the reset instantly, don't wait for the 500ms poll
                    resetOutputPanel("Fetching new local records...");

                    // Give the native page time to populate #output, then forward it
                    setTimeout(() => {
                        let transferBtn = document.querySelector("#send-to-sci-btn");
                        if (transferBtn) {
                            transferBtn.click();
                        } else {
                            console.log('SCI Bridge: #send-to-sci-btn not found yet - #output may still be rendering.');
                        }
                    }, 600);
                });
            }

            let outputDiv = document.querySelector("#output");
            if (outputDiv && outputDiv.innerText.trim() !== "" && !document.querySelector("#send-to-sci-btn")) {

                let btn = document.createElement("button");
                btn.id = "send-to-sci-btn";
                btn.type = "button";
                btn.className = "btn btn-warning";
                btn.style.marginLeft = "10px";
                btn.style.fontWeight = "bold";
                btn.innerText = "Send Data to Supreme Court Site";

                let actionArea = document.querySelector("input[value='Clear Values']");
                if (actionArea && actionArea.parentNode) {
                    actionArea.parentNode.appendChild(btn);
                } else {
                    outputDiv.insertBefore(btn, outputDiv.firstChild);
                }

                btn.addEventListener("click", function () {
                    let pageText = outputDiv.innerText;

                    let caseIdMatch = pageText.match(/[A-Z]+[-–]\d+[-–]\d{4}/i);
                    let caseNo = "";
                    if (caseIdMatch) {
                        let parts = caseIdMatch[0].split(/[-–]/);
                        if (parts.length >= 2) caseNo = parts[1];
                    }

                    let dateMatch = pageText.match(/(\d{1,2})[-–](JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[-–](\d{4})/i);
                    let formattedDate = dateMatch ? convertDateFormat(dateMatch[0]) : "";

                    if (caseNo || formattedDate) {
                        console.log(`SCI Bridge: Forwarding case ${caseNo}, date ${formattedDate} to SCI tab.`);
                        GM_setValue("sci_case_no", caseNo);
                        GM_setValue("sci_date", formattedDate);
                        GM_setValue("sci_search_results_html", "Data sent! Awaiting dynamic Captcha solution...");
                    } else {
                        document.querySelector("#sci-live-output").innerHTML = "Error: Text not ready in #output node yet. Click 'Send Data' button manually.";
                    }
                });
            }
        });

        observer.observe(document.body, { childList: true, subtree: true });
    }

    // ============================================================
    // SITE 2: SUPREME COURT OF INDIA CASE-STATUS SITE
    // ============================================================
    if (window.location.href.includes("sci.gov.in")) {

        // ---- 2a. Auto-select Court / State / Bench dropdowns ----
        let ddRetry = { state: 0, bench: 0 };
        const DD_MAX_RETRIES = 20;

        window.addEventListener('load', () => {
            setTimeout(selectCourtDropdown, 2000);
        });

        function selectCourtDropdown() {
            console.log('SCI Script: Looking for dropdowns...');
            const dropdowns = document.querySelectorAll('select');
            if (dropdowns.length >= 1) {
                const courtSelect = dropdowns[0];
                console.log('SCI Script: Found Court dropdown. Selecting "High Court"...');
                if (forceSelection(courtSelect, 'High Court')) {
                    setTimeout(selectStateDropdown, 1500);
                }
            } else {
                console.log('SCI Script: No dropdown elements found yet. Retrying...');
                setTimeout(selectCourtDropdown, 1000);
            }
        }

        function selectStateDropdown() {
            const dropdowns = document.querySelectorAll('select');
            if (dropdowns.length >= 2) {
                const stateSelect = dropdowns[1];
                if (stateSelect.options.length > 1) {
                    console.log('SCI Script: Found State dropdown. Selecting "Punjab"...');
                    if (forceSelection(stateSelect, 'Punjab')) {
                        setTimeout(selectBenchDropdown, 1500);
                    }
                } else if (ddRetry.state < DD_MAX_RETRIES) {
                    ddRetry.state++;
                    console.log(`SCI Script: Waiting for State server data... (${ddRetry.state})`);
                    setTimeout(selectStateDropdown, 500);
                }
            }
        }

        function selectBenchDropdown() {
            const dropdowns = document.querySelectorAll('select');
            const targetBench = 'High Court of Punjab & Haryana at Chandigarh HCPB';
            if (dropdowns.length >= 3) {
                const benchSelect = dropdowns[2];
                if (benchSelect.options.length > 1) {
                    console.log(`SCI Script: Found Bench dropdown. Selecting "${targetBench}"...`);
                    if (forceSelection(benchSelect, targetBench)) {
                        console.log('SCI Script: Dropdown automation complete!');
                    }
                } else if (ddRetry.bench < DD_MAX_RETRIES) {
                    ddRetry.bench++;
                    console.log(`SCI Script: Waiting for Bench server data... (${ddRetry.bench})`);
                    setTimeout(selectBenchDropdown, 500);
                }
            }
        }

        function forceSelection(selectElement, textToMatch) {
            let matchedIndex = -1;
            const target = textToMatch.trim().toLowerCase();
            for (let i = 0; i < selectElement.options.length; i++) {
                if (selectElement.options[i].text.trim().toLowerCase() === target) {
                    matchedIndex = i;
                    break;
                }
            }
            if (matchedIndex === -1) {
                console.log(`SCI Script: Option text "${textToMatch}" not available in this dropdown.`);
                return false;
            }
            selectElement.selectedIndex = matchedIndex;
            selectElement.value = selectElement.options[matchedIndex].value;
            selectElement.dispatchEvent(new Event('change', { bubbles: true }));
            selectElement.dispatchEvent(new Event('input', { bubbles: true }));
            if (typeof selectElement.onchange === 'function') selectElement.onchange();
            if (typeof jQuery !== 'undefined') {
                try { jQuery(selectElement).val(selectElement.value).trigger('change'); } catch (e) {}
            }
            return true;
        }

        // ---- 2b. Captcha image capture (only pushes when it actually changes) ----
        let lastCaptchaBase64 = null;
        let captchaNotFoundLogged = false;

        function findCaptchaImg() {
            return document.querySelector("img[src*='_siwp_captcha']")
                || document.querySelector("img[id*='captcha']")
                || document.querySelector("img[class*='captcha']")
                || document.querySelector("img[src*='captcha']");
        }

        setInterval(() => {
            let captchaImgNode = findCaptchaImg();

            if (!captchaImgNode) {
                if (!captchaNotFoundLogged) {
                    console.log('SCI Script: No captcha <img> found on page yet.');
                    captchaNotFoundLogged = true;
                }
                return;
            }
            captchaNotFoundLogged = false;

            if (!captchaImgNode.complete || captchaImgNode.naturalWidth === 0) {
                console.log(`SCI Script: Captcha img found but not fully loaded. Will retry.`);
                return;
            }

            let base64Str;
            if (captchaImgNode.src && captchaImgNode.src.startsWith('data:')) {
                base64Str = captchaImgNode.src;
            } else {
                base64Str = getBase64Image(captchaImgNode);
            }

            if (base64Str && base64Str !== lastCaptchaBase64) {
                lastCaptchaBase64 = base64Str;
                GM_setValue("sci_captcha_base64", base64Str);
                console.log(`SCI Script: Captcha image captured and pushed (${base64Str.length} chars).`);
            }
        }, 500);

        // ---- 2c. Results push: MutationObserver-based ----
        let lastPushedHTML = null;

        function pushResultsIfChanged() {
            let resultsHolder = document.querySelector(".resultsHolder.servicesResultsContainer");
            if (!resultsHolder) return;
            let clonedResults = resultsHolder.cloneNode(true);
            let loader = clonedResults.querySelector(".service-loader");
            if (loader) loader.remove();
            let htmlContent = clonedResults.innerHTML.trim();
            if (htmlContent && htmlContent !== lastPushedHTML) {
                lastPushedHTML = htmlContent;
                GM_setValue("sci_search_results_html", htmlContent);
                console.log('SCI Script: New results detected, pushed to weeding page panel.');
            }
        }

        function attachResultsObserver() {
            let target = document.querySelector(".resultsHolder.servicesResultsContainer");
            if (!target) return false;
            const resultsObserver = new MutationObserver(() => pushResultsIfChanged());
            resultsObserver.observe(target, { childList: true, subtree: true, characterData: true });
            pushResultsIfChanged();
            console.log('SCI Script: Results observer attached.');
            return true;
        }

        if (!attachResultsObserver()) {
            let findRetries = 0;
            const findInterval = setInterval(() => {
                if (attachResultsObserver() || ++findRetries > 40) {
                    clearInterval(findInterval);
                }
            }, 500);
        }

        // ---- 2d. Reset token watcher ----
        let lastResetToken = GM_getValue("sci_reset_token");
        setInterval(() => {
            let token = GM_getValue("sci_reset_token");
            if (token && token !== lastResetToken) {
                lastResetToken = token;
                lastPushedHTML = null;
                
                // FIX APPLIED HERE: Clears the local memory link to allow a clean captcha resync
                lastCaptchaBase64 = null; 
                
                console.log('SCI Script: Reset token changed - cleared cached results and captcha memory.');
            }
        }, 500);

        // ---- 2e. Fill case_no / date / captcha / trigger search ----
        setInterval(function () {
            let storedCaseNo = GM_getValue("sci_case_no");
            if (storedCaseNo) {
                let targetInput = document.querySelector("#case_no");
                if (targetInput) {
                    targetInput.value = storedCaseNo;
                    targetInput.dispatchEvent(new Event('input', { bubbles: true }));
                    targetInput.dispatchEvent(new Event('change', { bubbles: true }));
                    GM_setValue("sci_case_no", "");
                }
            }

            let storedDate = GM_getValue("sci_date");
            if (storedDate) {
                let targetDateInput = document.querySelector("#listing_date");
                if (targetDateInput) {
                    targetDateInput.value = storedDate;
                    targetDateInput.dispatchEvent(new Event('input', { bubbles: true }));
                    targetDateInput.dispatchEvent(new Event('change', { bubbles: true }));
                    GM_setValue("sci_date", "");
                }
            }

            let solvedCaptcha = GM_getValue("sci_captcha_solution");
            if (solvedCaptcha) {
                let captchaInputBox = document.querySelector("#siwp_captcha_value_0");
                if (captchaInputBox) {
                    captchaInputBox.value = solvedCaptcha;
                    captchaInputBox.dispatchEvent(new Event('input', { bubbles: true }));
                    captchaInputBox.dispatchEvent(new Event('change', { bubbles: true }));
                    GM_setValue("sci_captcha_solution", "");
                }
            }

            let triggerSubmit = GM_getValue("sci_trigger_submit");
            if (triggerSubmit === true) {
                let searchBtn = document.querySelector("input[name='submit'][value='Search']");
                if (searchBtn) {
                    GM_setValue("sci_trigger_submit", false);
                    searchBtn.click();
                }
            }
        }, 500);
    }
})();