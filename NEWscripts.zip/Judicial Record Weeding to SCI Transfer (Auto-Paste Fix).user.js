// ==UserScript==
// @name         Judicial Record Weeding to SCI Transfer (Auto-Paste Fix)
// @namespace    http://tampermonkey.net/
// @version      1.4
// @match        http://10.145.22.11:8888/add_weeding_details.php*
// @match        https://www.sci.gov.in/case-status-court/*
// @grant        GM_setValue
// @grant        GM_getValue
// ==/UserScript==

(function() {
    'use strict';

    // ---------- helpers ----------
    function convertDateFormat(dateStr) {
        if (!dateStr) return "";
        const months = {
            "JAN": "01", "FEB": "02", "MAR": "03", "APR": "04", "MAY": "05", "JUN": "06",
            "JUL": "07", "AUG": "08", "SEP": "09", "OCT": "10", "NOV": "11", "DEC": "12"
        };
        let parts = dateStr.toUpperCase().split('-');
        if (parts.length === 3) {
            let day = parts[0].padStart(2, '0');
            let monthName = parts[1];
            let year = parts[2];
            let monthNum = months[monthName] || monthName;
            return `${day}-${monthNum}-${year}`;
        }
        return dateStr;
    }

    // Poll for a condition (fn returns truthy when ready) up to timeoutMs, then call cb(true/false)
    function waitFor(fn, timeoutMs, intervalMs, cb) {
        let waited = 0;
        let iv = setInterval(function() {
            let result = fn();
            if (result) {
                clearInterval(iv);
                cb(true, result);
            } else if (waited >= timeoutMs) {
                clearInterval(iv);
                cb(false, null);
            }
            waited += intervalMs;
        }, intervalMs);
    }

    // Set a native <select>'s value by matching visible option text (case-insensitive, partial match ok),
    // then trigger jQuery 'change' so select2 / any listeners sync up.
    function setSelectByText($, selectEl, text) {
        if (!selectEl) return false;
        let opts = Array.from(selectEl.options);
        let match = opts.find(o => o.text.trim().toLowerCase() === text.trim().toLowerCase());
        if (!match) {
            match = opts.find(o => o.text.trim().toLowerCase().includes(text.trim().toLowerCase()));
        }
        if (!match) return false;
        $(selectEl).val(match.value).trigger('change');
        return true;
    }

    // ---------- SITE 1: WEEDING DETAILS SITE ----------
    if (window.location.href.includes("10.145.22.11")) {

        const observer = new MutationObserver((mutations, obs) => {
            let outputDiv = document.querySelector("#output");
            if (outputDiv && outputDiv.innerText.trim() !== "" && !document.querySelector("#send-to-sci-btn")) {

                let btn = document.createElement("button");
                btn.id = "send-to-sci-btn";
                btn.type = "button";
                btn.className = "btn btn-warning";
                btn.style.marginLeft = "10px";
                btn.style.fontWeight = "bold";
                btn.innerText = "Send Data to Supreme Court Site";

                let actionArea = document.querySelector("input[value='Clear Values']");
                if (actionArea && actionArea.parentNode) {
                    actionArea.parentNode.appendChild(btn);
                } else {
                    outputDiv.insertBefore(btn, outputDiv.firstChild);
                }

                btn.addEventListener("click", function() {
                    let pageText = outputDiv.innerText;

                    let caseIdMatch = pageText.match(/[A-Z]+[-–]\d+[-–]\d{4}/i);
                    let caseNo = "";
                    if (caseIdMatch) {
                        let fullCaseId = caseIdMatch[0];
                        let parts = fullCaseId.split(/[-–]/);
                        if (parts.length >= 2) {
                            caseNo = parts[1];
                        }
                    }

                    let dateMatch = pageText.match(/(\d{1,2})[-–](JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[-–](\d{4})/i);
                    let formattedDate = "";
                    if (dateMatch) {
                        formattedDate = convertDateFormat(dateMatch[0]);
                    }

                    if (caseNo || formattedDate) {
                        GM_setValue("sci_case_no", caseNo);
                        GM_setValue("sci_date", formattedDate);

                        let originalText = btn.innerText;
                        btn.innerText = "✓ Sent!";
                        btn.className = "btn btn-success";
                        setTimeout(() => {
                            btn.innerText = originalText;
                            btn.className = "btn btn-warning";
                        }, 2000);
                    } else {
                        alert("Could not extract Case ID or Decision Date from the page content.");
                    }
                });
            }
        });

        observer.observe(document.body, { childList: true, subtree: true });
    }

    // ---------- SITE 2: SUPREME COURT SITE ----------
    if (window.location.href.includes("sci.gov.in")) {
        console.log("[SCI script] loaded on", window.location.href);

        function startDataPollingLoop() {
            setInterval(function() {
                let storedCaseNo = GM_getValue("sci_case_no");
                let storedDate = GM_getValue("sci_date");

                if (storedCaseNo) {
                    let targetInput = document.querySelector("#case_no");
                    if (targetInput) {
                        targetInput.value = storedCaseNo;
                        targetInput.dispatchEvent(new Event('input', { bubbles: true }));
                        targetInput.dispatchEvent(new Event('change', { bubbles: true }));
                        GM_setValue("sci_case_no", "");
                    }
                }

                if (storedDate) {
                    let targetDateInput = document.querySelector("#listing_date");
                    if (targetDateInput) {
                        targetDateInput.value = storedDate;
                        targetDateInput.dispatchEvent(new Event('input', { bubbles: true }));
                        targetDateInput.dispatchEvent(new Event('change', { bubbles: true }));
                        GM_setValue("sci_date", "");
                    }
                }
            }, 1000);
        }

        // Run the Court/State/Bench selection exactly once, ever (per browser profile).
        // On every later visit we skip straight to the polling loop.
        const ONE_TIME_FLAG = "sci_court_state_bench_prefilled";

        function runOneTimeFormSetup() {
            console.log("[SCI script] runOneTimeFormSetup() starting");

            // jQuery is loaded on this site (jquery-core-js). Wait for it before touching select2 selects.
            waitFor(() => (window.jQuery ? window.jQuery : false), 15000, 300, function(ok, $) {
                console.log("[SCI script] jQuery found?", ok);
                if (!ok) {
                    console.warn("[SCI script] jQuery not found, skipping auto-fill; falling back to polling only.");
                    startDataPollingLoop();
                    return;
                }

                // Step 1: click the "Court" tab so the by-court form is the active one.
                waitFor(() => {
                    let links = Array.from(document.querySelectorAll("a.btn.btn-style-outline"));
                    return links.find(a => a.textContent.trim().toLowerCase() === "court") || null;
                }, 10000, 300, function(found, courtTabLink) {
                    console.log("[SCI script] Court tab link found?", found);
                    if (found) {
                        courtTabLink.click();
                    }

                    // small pause before touching the form, then step 2: Court -> High Court
                    setTimeout(function() {
                        waitFor(() => document.querySelector("#case_status_court"), 10000, 300, function(found2, courtSelect) {
                            console.log("[SCI script] #case_status_court found?", found2);
                            if (!found2) { startDataPollingLoop(); return; }

                            let didSetCourt = setSelectByText($, courtSelect, "High Court");
                            console.log("[SCI script] set Court to High Court?", didSetCourt);

                            // Step 3: wait for the State select2 widget to appear/refresh, then choose Punjab
                            setTimeout(function() {
                                waitFor(() => document.querySelector("#case_status_state"), 15000, 400, function(found3, stateSelect) {
                                    console.log("[SCI script] #case_status_state found?", found3);
                                    if (!found3) { startDataPollingLoop(); return; }

                                    // open the select2 UI briefly (harmless, matches the manual click flow) then set value
                                    let stateContainer = document.querySelector("#select2-case_status_state-container");
                                    if (stateContainer && stateContainer.closest(".select2-selection")) {
                                        stateContainer.closest(".select2-selection").click();
                                    }

                                    setTimeout(function() {
                                        let didSetState = setSelectByText($, stateSelect, "Punjab");
                                        console.log("[SCI script] set State to Punjab?", didSetState,
                                            "available options:", Array.from(stateSelect.options).map(o => o.text));

                                        // Step 4: wait for Bench options to load after state change, then choose Chandigarh bench
                                        setTimeout(function() {
                                            waitFor(() => {
                                                let benchSelect = document.querySelector("#case_status_bench");
                                                if (!benchSelect) return null;
                                                let hasOptions = Array.from(benchSelect.options).some(o =>
                                                    o.text.toLowerCase().includes("chandigarh"));
                                                return hasOptions ? benchSelect : null;
                                            }, 15000, 400, function(found4, benchSelect) {
                                                console.log("[SCI script] bench options with 'chandigarh' found?", found4);
                                                if (found4) {
                                                    let didSetBench = setSelectByText($, benchSelect, "High Court of Punjab & Haryana at Chandigarh HCPB");
                                                    console.log("[SCI script] set Bench?", didSetBench,
                                                        "available bench options:", Array.from(benchSelect.options).map(o => o.text));
                                                }
                                                // Mark as done so future page loads skip straight to polling.
                                                GM_setValue(ONE_TIME_FLAG, true);
                                                console.log("[SCI script] one-time setup complete, starting polling loop");
                                                startDataPollingLoop();
                                            });
                                        }, 1200);
                                    }, 800);
                                });
                            }, 1200);
                        });
                    }, 1000);
                });
            });
        }

        console.log("[SCI script] one-time flag already set?", GM_getValue(ONE_TIME_FLAG, false));
        if (GM_getValue(ONE_TIME_FLAG, false)) {
            startDataPollingLoop();
        } else {
            runOneTimeFormSetup();
        }
    }
})();