// ==UserScript==
// @name         Judicial Record Weeding to SCI Transfer (Instant Output Reset)
// @namespace    http://tampermonkey.net/
// @version      1.7
// @match        http://10.145.22.11:8888/add_weeding_details.php*
// @match        https://www.sci.gov.in/case-status-court/*
// @grant        GM_setValue
// @grant        GM_getValue
// ==/UserScript==

(function() {
    'use strict';

    // Helper to convert date from "21-SEP-2020" format to "21-09-2020" format
    function convertDateFormat(dateStr) {
        if (!dateStr) return "";
        const months = {
            "JAN": "01", "FEB": "02", "MAR": "03", "APR": "04", "MAY": "05", "JUN": "06",
            "JUL": "07", "AUG": "08", "SEP": "09", "OCT": "10", "NOV": "11", "DEC": "12"
        };
        let parts = dateStr.toUpperCase().split('-');
        if (parts.length === 3) {
            let day = parts[0].padStart(2, '0');
            let monthName = parts[1];
            let year = parts[2];
            let monthNum = months[monthName] || monthName; 
            return `${day}-${monthNum}-${year}`;
        }
        return dateStr;
    }

    // Helper to convert an image element to a Base64 string
    function getBase64Image(img) {
        try {
            let canvas = document.createElement("canvas");
            canvas.width = img.naturalWidth || img.width;
            canvas.height = img.naturalHeight || img.height;
            let ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0);
            return canvas.toDataURL("image/png");
        } catch (e) {
            console.error("Failed to convert image to Base64", e);
            return null;
        }
    }

    // --- SITE 1: WEEDING DETAILS SITE ---
    if (window.location.href.includes("10.145.22.11")) {
        
        // Create Captcha UI Box + Output Window at top right
        let captchaContainer = document.createElement("div");
        captchaContainer.id = "sci-captcha-container";
        captchaContainer.style = "position: fixed; top: 10px; right: 10px; z-index: 9999; padding: 10px; background: #fff; border: 2px solid #ffc107; border-radius: 5px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 220px; text-align: center; max-height: 90vh; overflow-y: auto;";
        captchaContainer.innerHTML = `
            <div style="font-weight:bold; font-size:12px; margin-bottom:5px; color:#333;">SCI Captcha</div>
            <img id="sci-captcha-img" src="" alt="Waiting for SCI site..." style="max-width: 100%; border: 1px solid #ccc; height: 40px; background: #eee; display: block; margin: 0 auto 5px auto;"/>
            <input type="text" id="sci-captcha-input" placeholder="Enter Captcha" style="width: 100%; padding: 4px; box-sizing: border-box; text-align: center; margin-bottom: 5px; border: 1px solid #ccc; border-radius:3px;"/>
            <button type="button" id="sci-captcha-submit" class="btn btn-primary" style="width: 100%; font-weight: bold; padding: 5px; font-size:12px; margin-bottom: 10px;">Submit to SCI</button>
            
            <hr style="border: 0; border-top: 1px solid #ccc; margin: 10px 0;">
            
            <div style="font-weight:bold; font-size:11px; margin-bottom:5px; color:#555; text-align: left;">Supreme Court Output:</div>
            <div id="sci-live-output" style="font-size: 11px; text-align: left; padding: 5px; background: #fafafa; border: 1px dashed #aaa; min-height: 40px; max-height: 300px; overflow-y: auto; color: #333;">
                Waiting for search...
            </div>
        `;
        document.body.appendChild(captchaContainer);

        // Periodically pull captcha images and live search results from storage
        setInterval(() => {
            let base64Img = GM_getValue("sci_captcha_base64");
            let imgElement = document.querySelector("#sci-captcha-img");
            if (imgElement) {
                // If storage is explicitly emptied, show placeholder text
                imgElement.src = base64Img ? base64Img : "";
                if (!base64Img) imgElement.alt = "Awaiting new captcha...";
            }

            let liveOutput = GM_getValue("sci_search_results_html");
            let outputDiv = document.querySelector("#sci-live-output");
            if (outputDiv) {
                outputDiv.innerHTML = liveOutput ? liveOutput : "Waiting for search...";
            }
        }, 500); // Increased frequency to 500ms for snappier UI synchronization

        // Handle Captcha submission
        document.querySelector("#sci-captcha-submit").addEventListener("click", function() {
            let val = document.querySelector("#sci-captcha-input").value.trim();
            if (val) {
                GM_setValue("sci_search_results_html", "Processing search request..."); 
                GM_setValue("sci_captcha_solution", val);
                GM_setValue("sci_trigger_submit", true);
                document.querySelector("#sci-captcha-input").value = ""; 
            } else {
                alert("Please enter the captcha value first.");
            }
        });
        
        // Monitor page for the native components and handle clicks
        const observer = new MutationObserver((mutations, obs) => {
            let nativeSubmitBtn = document.querySelector("button[name='btn_diary']");
            if (nativeSubmitBtn && !nativeSubmitBtn.classList.contains("patched-chain")) {
                nativeSubmitBtn.classList.add("patched-chain");
                
                nativeSubmitBtn.addEventListener("click", function() {
                    // CRITICAL FIX: Instantly scrub global storage keys so old text disappears
                    GM_setValue("sci_search_results_html", "Fetching new local records...");
                    GM_setValue("sci_captcha_base64", ""); 
                    
                    // Force clean local view immediately without waiting for the interval tick
                    document.querySelector("#sci-captcha-input").value = "";
                    document.querySelector("#sci-live-output").innerHTML = "Fetching new local records...";
                    document.querySelector("#sci-captcha-img").src = "";
                    
                    // Trigger the data migration block after a slight pause to allow the native local query to populate
                    setTimeout(() => {
                        let transferBtn = document.querySelector("#send-to-sci-btn");
                        if (transferBtn) {
                            transferBtn.click();
                        }
                    }, 600);
                });
            }

            let outputDiv = document.querySelector("#output");
            if (outputDiv && outputDiv.innerText.trim() !== "" && !document.querySelector("#send-to-sci-btn")) {
                
                let btn = document.createElement("button");
                btn.id = "send-to-sci-btn";
                btn.type = "button";
                btn.className = "btn btn-warning";
                btn.style.marginLeft = "10px";
                btn.style.fontWeight = "bold";
                btn.innerText = "Send Data to Supreme Court Site";
                
                let actionArea = document.querySelector("input[value='Clear Values']");
                if (actionArea && actionArea.parentNode) {
                    actionArea.parentNode.appendChild(btn);
                } else {
                    outputDiv.insertBefore(btn, outputDiv.firstChild);
                }

                btn.addEventListener("click", function() {
                    let pageText = outputDiv.innerText;

                    let caseIdMatch = pageText.match(/[A-Z]+[-–]\d+[-–]\d{4}/i);
                    let caseNo = "";
                    if (caseIdMatch) {
                        let fullCaseId = caseIdMatch[0]; 
                        let parts = fullCaseId.split(/[-–]/);
                        if (parts.length >= 2) {
                            caseNo = parts[1]; 
                        }
                    }

                    let dateMatch = pageText.match(/(\d{1,2})[-–](JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[-–](\d{4})/i);
                    let formattedDate = "";
                    if (dateMatch) {
                        formattedDate = convertDateFormat(dateMatch[0]);
                    }

                    if (caseNo || formattedDate) {
                        GM_setValue("sci_case_no", caseNo);
                        GM_setValue("sci_date", formattedDate);
                        GM_setValue("sci_search_results_html", "Data sent! Awaiting dynamic Captcha solution...");
                    } else {
                        // Soft recovery if native DOM took slightly longer to write text
                        document.querySelector("#sci-live-output").innerHTML = "Error: Text not ready in #output node yet. Click 'Send Data' button manually.";
                    }
                });
            }
        });

        observer.observe(document.body, { childList: true, subtree: true });
    }

    // --- SITE 2: SUPREME COURT SITE ---
    if (window.location.href.includes("sci.gov.in")) {
        
        setInterval(function() {
            let captchaImgNode = document.querySelector("img[src*='_siwp_captcha']");
            if (captchaImgNode && captchaImgNode.complete) {
                let base64Str = getBase64Image(captchaImgNode);
                if (base64Str) {
                    GM_setValue("sci_captcha_base64", base64Str);
                }
            }

            let resultsHolder = document.querySelector(".resultsHolder.servicesResultsContainer");
            if (resultsHolder) {
                let clonedResults = resultsHolder.cloneNode(true);
                let loader = clonedResults.querySelector(".service-loader");
                if (loader) loader.remove();
                
                let htmlContent = clonedResults.innerHTML.trim();
                if (htmlContent) {
                    GM_setValue("sci_search_results_html", htmlContent);
                }
            }

            let storedCaseNo = GM_getValue("sci_case_no");
            if (storedCaseNo) {
                let targetInput = document.querySelector("#case_no");
                if (targetInput) {
                    targetInput.value = storedCaseNo;
                    targetInput.dispatchEvent(new Event('input', { bubbles: true }));
                    targetInput.dispatchEvent(new Event('change', { bubbles: true }));
                    GM_setValue("sci_case_no", ""); 
                }
            }

            let storedDate = GM_getValue("sci_date");
            if (storedDate) {
                let targetDateInput = document.querySelector("#listing_date");
                if (targetDateInput) {
                    targetDateInput.value = storedDate;
                    targetDateInput.dispatchEvent(new Event('input', { bubbles: true }));
                    targetDateInput.dispatchEvent(new Event('change', { bubbles: true }));
                    GM_setValue("sci_date", ""); 
                }
            }

            let solvedCaptcha = GM_getValue("sci_captcha_solution");
            if (solvedCaptcha) {
                let captchaInputBox = document.querySelector("#siwp_captcha_value_0");
                if (captchaInputBox) {
                    captchaInputBox.value = solvedCaptcha;
                    captchaInputBox.dispatchEvent(new Event('input', { bubbles: true }));
                    captchaInputBox.dispatchEvent(new Event('change', { bubbles: true }));
                    GM_setValue("sci_captcha_solution", ""); 
                }
            }

            let triggerSubmit = GM_getValue("sci_trigger_submit");
            if (triggerSubmit === true) {
                let searchBtn = document.querySelector("input[name='submit'][value='Search']");
                if (searchBtn) {
                    GM_setValue("sci_trigger_submit", false);
                    searchBtn.click();
                }
            }
        }, 500); // 500ms loop context check matching the display side rate
    }
})();